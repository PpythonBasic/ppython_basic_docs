import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error

data = {"Height (cm)": [120, 130, 140, 150, 160], "Weight (kg)": [22, 28, 35, 42, 50]}
df = pd.DataFrame(data)

X = df[["Height (cm)"]]
y = df["Weight (kg)"]
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

model = LinearRegression()
model.fit(X_train, y_train)

y_pred = model.predict(X_test)
print(y_pred)

mse = mean_squared_error(y_test, y_pred)
print(f"Mean Squared Error: {mse}")

new_heights = [[125], [145], [155]]  # ต้องอยู่ในรูปแบบของลิสต์ 2 มิติ

# ทำนายน้ำหนัก
predicted_weights = model.predict(new_heights)

# แสดงผลลัพธ์
for height, weight in zip(new_heights, predicted_weights):
    print(f"ความสูง {height[0]} cm ทำนายน้ำหนัก {weight:.2f} kg")
