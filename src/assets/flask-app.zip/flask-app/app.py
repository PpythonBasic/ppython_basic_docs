from flask import Flask, render_template

app = Flask(__name__)


@app.route("/")
def home():
    return render_template("index.html", title="หน้าแรก", message="สวัสดีเด็กๆ!")


@app.route("/about")
def about():
    return render_template("index.html", title="เกี่ยวกับเรา", message="นี่คือหน้าเกี่ยวกับเรา")


if __name__ == "__main__":
    app.run(debug=True)
